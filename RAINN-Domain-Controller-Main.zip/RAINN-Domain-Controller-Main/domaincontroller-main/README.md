# domaincontroller
'https://www.usom.gov.tr/adres' adresinde Google reklamları için açtığınız alan adlarının yakalanıp yakalanmadığını kontrol eden alan adı denetleyicisi